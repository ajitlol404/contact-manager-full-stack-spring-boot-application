package com.cm.dao;

import com.cm.entity.ApplicationSetting;
import com.cm.entity.ApplicationSetting.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ApplicationSettingRepository extends JpaRepository<ApplicationSetting, String> {

    List<ApplicationSetting> findByCategory(Category category);

    Optional<ApplicationSetting> findByKey(String key);

    Optional<ApplicationSetting> findByKeyAndCategory(String key, ApplicationSetting.Category category);


}
