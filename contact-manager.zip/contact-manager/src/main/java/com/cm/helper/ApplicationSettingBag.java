package com.cm.helper;

import com.cm.entity.ApplicationSetting;
import com.cm.entity.ApplicationSetting.Category;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RequiredArgsConstructor
public class ApplicationSettingBag {

    private final List<ApplicationSetting> listAllApplicationSetting;

    public ApplicationSetting get(String key) {
        return listAllApplicationSetting.stream()
                .filter(setting -> setting.getKey().equals(key))
                .findFirst()
                .orElse(null);
    }

    public ApplicationSetting get(String key, Category category) {
        return listAllApplicationSetting.stream()
                .filter(setting -> setting.getKey().equals(key) && setting.getCategory() == category)
                .findFirst()
                .orElse(null);
    }

    public String getValue(String key) {
        ApplicationSetting setting = get(key);
        return setting != null ? setting.getValue() : null;
    }

    public String getValue(String key, Category category) {
        ApplicationSetting setting = get(key, category);
        return setting != null ? setting.getValue() : null;
    }

    public void update(String key, String value) {
        ApplicationSetting setting = get(key);
        if (setting != null && value != null) {
            setting.setValue(value);
        }
    }

    public void update(String key, String value, Category category) {
        ApplicationSetting setting = get(key, category);
        if (setting != null && value != null) {
            setting.setValue(value);
        }
    }

    public List<ApplicationSetting> list() {
        return listAllApplicationSetting;
    }

}