package com.cm.helper;

public final class AppConstant {
    private AppConstant() {}

    public static final String CONTACT_BASE_URL = "/contacts";
}
