package com.cm.helper;

public final class AppConstant {

    private AppConstant() {
    }

    public static final String API_VERSION = "/v1";

    public static final String SMTP_BASE_URL = "/smtp";
    public static final String USER_BASE_URL = "/users";
    public static final String CONTACT_BASE_URL = "/contacts";


    public static final String SMTP_HOST = "SMTP_HOST";
    public static final String SMTP_PORT = "SMTP_PORT";
    public static final String SMTP_USERNAME = "SMTP_USERNAME";
    public static final String SMTP_PASSWORD = "SMTP_PASSWORD";
    public static final String SMTP_IS_SSL = "SMTP_IS_SSL";
    public static final String SMTP_STATUS = "SMTP_STATUS";


}
