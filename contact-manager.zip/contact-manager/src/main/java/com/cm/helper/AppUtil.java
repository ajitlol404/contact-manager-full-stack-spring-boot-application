package com.cm.helper;

import java.util.Base64;

public class AppUtil {

    public static String encode(String input) {
        return Base64.getEncoder().encodeToString(input.getBytes());
    }

    public static String protectEmail(String email) {
        return email.replaceAll("(^[^@]{1}|(?!^)\\G)[^@]", "$1*");
    }

}
