package com.cm.backend.service.impl;

import com.cm.backend.service.ContactDetailService;
import org.springframework.stereotype.Service;

@Service
public class ContactDetailServiceImpl implements ContactDetailService {
}
