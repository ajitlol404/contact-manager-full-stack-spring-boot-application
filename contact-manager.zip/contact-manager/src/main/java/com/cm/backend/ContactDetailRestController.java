package com.cm.backend;

import com.cm.helper.dto.ContactDTO.ContactInputDTO;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.cm.helper.AppConstant.CONTACT_BASE_URL;

@RestController
@RequestMapping(CONTACT_BASE_URL)
public class ContactDetailRestController {

    @PostMapping
    public void createContact(@ModelAttribute ContactInputDTO contactInputDTO) {
        System.out.println(contactInputDTO);
    }
}
