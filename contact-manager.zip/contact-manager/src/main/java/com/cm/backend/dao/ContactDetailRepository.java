package com.cm.backend.dao;

import com.cm.backend.entity.ContactDetail;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ContactDetailRepository extends JpaRepository<ContactDetail, UUID> {
}
