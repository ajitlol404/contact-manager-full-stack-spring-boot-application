package com.cm.backend.service;

public interface ContactDetailService {
}
