package com.cm.backend.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ContactDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(length = 320)
    private String email;

    private LocalDate dob;

    @Column(length = 200)
    private String address;

    @Column(length = 100)
    private String image;

    @Column(nullable = false)
    private Set<String> phoneNumbers = new HashSet<>();

}
