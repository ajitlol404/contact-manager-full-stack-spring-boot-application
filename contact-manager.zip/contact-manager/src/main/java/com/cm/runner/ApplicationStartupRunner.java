package com.cm.runner;

import com.cm.dao.ApplicationSettingRepository;
import com.cm.entity.ApplicationSetting;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.cm.entity.ApplicationSetting.Category.APP_VERSION;
import static com.cm.entity.ApplicationSetting.Category.SMTP;
import static com.cm.helper.AppConstant.*;

@Order(1)
@Component
@RequiredArgsConstructor
public class ApplicationStartupRunner implements CommandLineRunner {

    private final ApplicationSettingRepository applicationSettingRepository;

    @Override
    public void run(String... args) throws Exception {
        List<ApplicationSetting> allSettings = applicationSettingRepository.findAll();

        // Initialize application
        initializeSetting(SMTP_HOST, null, SMTP);
        initializeSetting(SMTP_PORT, null, SMTP);
        initializeSetting(SMTP_USERNAME, null, SMTP);
        initializeSetting(SMTP_PASSWORD, null, SMTP);
        initializeSetting(SMTP_IS_SSL, null, SMTP);
        initializeSetting(SMTP_STATUS, null, SMTP);

        initializeSetting(APP_VERSION.name(), "1.0", APP_VERSION);

        // Persist any new settings to the database
        allSettings.forEach(applicationSettingRepository::save);
    }


    private void initializeSetting(String key, String initialValue, ApplicationSetting.Category category) {
        if (applicationSettingRepository.findByKeyAndCategory(key, category).isEmpty()) {
            ApplicationSetting setting = new ApplicationSetting(key, initialValue, category);
            applicationSettingRepository.save(setting);
        }
    }

}
