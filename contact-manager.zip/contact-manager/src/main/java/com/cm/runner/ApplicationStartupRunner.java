package com.cm.runner;

import com.cm.entity.ApplicationSetting;
import com.cm.entity.ApplicationSetting.Category;
import com.cm.exception.ResourceNotFoundException;
import com.cm.service.ApplicationSettingService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.cm.entity.ApplicationSetting.Category.APP_VERSION;
import static com.cm.entity.ApplicationSetting.Category.SMTP;
import static com.cm.helper.AppConstant.*;

@Order(1)
@Component
@RequiredArgsConstructor
public class ApplicationStartupRunner implements CommandLineRunner {

    private final ApplicationSettingService applicationSettingService;

    @Override
    public void run(String... args) throws Exception {

        // Initialize application
        initializeSetting(SMTP_HOST, null, SMTP);
        initializeSetting(SMTP_PORT, null, SMTP);
        initializeSetting(SMTP_USERNAME, null, SMTP);
        initializeSetting(SMTP_PASSWORD, null, SMTP);
        initializeSetting(SMTP_IS_SSL, null, SMTP);
        initializeSetting(SMTP_STATUS, null, SMTP);
        initializeSetting(APP_VERSION.name(), "CM_1.0", APP_VERSION);

        // Display application version
        displayApplicationVersion();
    }

    private void initializeSetting(String key, String initialValue, Category category) {
        try {
            ApplicationSetting setting = applicationSettingService.getApplicationSettingByKey(key);
            // Setting exists, do nothing
        } catch (ResourceNotFoundException e) {
            // Setting doesn't exist, create and save
            ApplicationSetting newSetting = ApplicationSetting.builder()
                    .key(key)
                    .value(initialValue)
                    .category(category)
                    .build();
            applicationSettingService.saveAllApplicationSetting(List.of(newSetting));
        }
    }

    private void displayApplicationVersion() {
        try {
            ApplicationSetting versionSetting = applicationSettingService.getApplicationSettingByKey(APP_VERSION.name());
            String version = versionSetting.getValue();
            System.out.printf("Welcome to Contact Manager [VERSION: %s]", version);
        } catch (ResourceNotFoundException e) {
            // Handle if version setting is not found (though it should exist based on initialization logic)
            System.out.println("Welcome to Contact Manager");
        }
    }

}
