package com.cm.runner;

import com.cm.dao.ApplicationSettingRepository;
import com.cm.entity.ApplicationSetting;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import static com.cm.entity.ApplicationSetting.Category.APP_VERSION;
import static com.cm.entity.ApplicationSetting.Category.SMTP;
import static com.cm.helper.AppConstant.*;

@Order(1)
@Component
@RequiredArgsConstructor
public class ApplicationStartupRunner implements CommandLineRunner {

    private final ApplicationSettingRepository applicationSettingRepository;

    @Override
    public void run(String... args) throws Exception {

        // Initialize application
        initializeSetting(SMTP_HOST, "", SMTP);
        initializeSetting(SMTP_PORT, "", SMTP);
        initializeSetting(SMTP_USERNAME, "", SMTP);
        initializeSetting(SMTP_PASSWORD, "", SMTP);
        initializeSetting(SMTP_IS_SSL, "", SMTP);
        initializeSetting(SMTP_IS_ENABLED, Boolean.FALSE.toString(), SMTP);
        initializeSetting(APP_VERSION.name(), "1.0", APP_VERSION);

    }

    private void initializeSetting(String key, String initialValue, ApplicationSetting.Category category) {
        applicationSettingRepository.findById(key).orElseGet(() -> {
            ApplicationSetting setting = ApplicationSetting.builder()
                    .key(key)
                    .value(initialValue)
                    .category(category)
                    .build();
            return applicationSettingRepository.save(setting);
        });
    }

}
