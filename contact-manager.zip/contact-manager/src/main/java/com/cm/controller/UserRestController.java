package com.cm.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.cm.helper.AppConstant.USER_BASE_URL;

@RestController
@RequestMapping(USER_BASE_URL)
public class UserRestController {

    @PostMapping
    public void createUser() {
    }
}
