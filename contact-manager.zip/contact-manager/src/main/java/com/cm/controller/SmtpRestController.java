package com.cm.controller;

import com.cm.dto.SmtpDTO.SmtpInputDTO;
import com.cm.dto.SmtpDTO.SmtpResponseDTO;
import com.cm.service.SmtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import static com.cm.helper.AppConstant.SMTP_BASE_URL;

@RestController
@RequestMapping(SMTP_BASE_URL)
@RequiredArgsConstructor
public class SmtpRestController {

    private final SmtpService smtpService;

    @PostMapping
    public void createSmtp(@RequestBody SmtpInputDTO smtpInputDTO) {
        System.out.println(smtpInputDTO);
    }

    @GetMapping
    public SmtpResponseDTO getSmtp() {
        return smtpService.getSmtp();
    }

    @PutMapping
    public void updateSmtp(@RequestBody SmtpInputDTO smtpInputDTO) {
        System.out.println();
    }
}
