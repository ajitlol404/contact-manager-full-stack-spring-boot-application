package com.cm.controller;

import com.cm.dto.SmtpDTO.SmtpInputDTO;
import com.cm.dto.SmtpDTO.SmtpResponseDTO;
import com.cm.dto.SmtpDTO.SmtpToggleStatusDTO;
import com.cm.service.SmtpService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import static com.cm.helper.AppConstant.API_VERSION;
import static com.cm.helper.AppConstant.SMTP_BASE_URL;

@RestController
@RequestMapping(API_VERSION + SMTP_BASE_URL)
@RequiredArgsConstructor
public class SmtpRestController {

    private final SmtpService smtpService;

    @PutMapping
    public SmtpResponseDTO updateSmtp(@RequestBody @Valid SmtpInputDTO smtpInputDTO) {
        return smtpService.updateSmtp(smtpInputDTO);
    }

    @GetMapping
    public SmtpResponseDTO getSmtp() {
        return smtpService.getSmtp();
    }

    @PutMapping("/toggle")
    public SmtpToggleStatusDTO toggleSmtpStatus(@RequestBody SmtpToggleStatusDTO smtpToggleStatusDTO) {
        return smtpService.toggleSmtpStatus(smtpToggleStatusDTO);
    }
}
