package com.cm.controller;

import com.cm.dto.SmtpDTO.SmtpInputDTO;
import org.springframework.web.bind.annotation.*;

import static com.cm.helper.AppConstant.SMTP_BASE_URL;

@RestController
@RequestMapping(SMTP_BASE_URL)
public class SmtpRestController {

    @PostMapping
    public void createSmtp(@RequestBody SmtpInputDTO smtpInputDTO) {
        System.out.println(smtpInputDTO);
    }

    @GetMapping
    public void getSmtp() {
        System.out.println();
    }

    @PutMapping
    public void updateSmtp(@RequestBody SmtpInputDTO smtpInputDTO) {
        System.out.println();
    }
}
