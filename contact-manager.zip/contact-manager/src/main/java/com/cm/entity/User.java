package com.cm.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "cm_user")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(nullable = false, length = 50)
    private String username;

    @Column(length = 320)
    private String email;

    private String password;

    @CreationTimestamp
    private LocalDateTime dateJoined;

    @JdbcTypeCode(SqlTypes.JSON)
    private UserData userData;

    @Column(nullable = false)
    private boolean enabled;

    @Enumerated(EnumType.STRING)
    private Role role;

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class UserData implements Serializable {

        @Serial
        private static final long serialVersionUID = 1L;

        private String secretKey;

        private boolean secretKeyStatus;
    }

    public enum Role {
        ROLE_ADMIN, ROLE_USER;
    }

}
