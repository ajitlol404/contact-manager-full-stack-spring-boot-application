package com.cm.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "cm_application_setting")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Builder
public class ApplicationSetting {

    @Id
    @Column(name = "\"key\"")
    private String key;

    private String value;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Category category;

    public enum Category {
        SMTP,
        APP_VERSION
    }

    public ApplicationSetting(String key) {
        this.key = key;
    }

}
