package com.cm.service.impl;

import com.cm.dao.UserRepository;
import com.cm.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import static com.cm.entity.User.Role.ROLE_ADMIN;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public boolean areThereAdminUsers() {
        return userRepository.existsByRole(ROLE_ADMIN);
    }
}
