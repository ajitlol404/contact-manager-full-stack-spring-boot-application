package com.cm.service.impl;

import com.cm.dao.ApplicationSettingRepository;
import com.cm.entity.ApplicationSetting;
import com.cm.entity.ApplicationSetting.Category;
import com.cm.exception.ResourceNotFoundException;
import com.cm.service.ApplicationSettingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ApplicationSettingServiceImpl implements ApplicationSettingService {

    private final ApplicationSettingRepository applicationSettingRepository;

    @Override
    public List<ApplicationSetting> getAllApplicationSettings() {
        return applicationSettingRepository.findAll();
    }

    @Override
    public void saveAllApplicationSetting(Iterable<ApplicationSetting> applicationSettings) {
        applicationSettingRepository.saveAll(applicationSettings);
    }

    @Override
    public List<ApplicationSetting> getApplicationSettingsByCategory(Category category) {
        return applicationSettingRepository.findByCategory(category);
    }

    @Override
    public ApplicationSetting getApplicationSettingByKey(String key) {
        return applicationSettingRepository.findByKey(key).orElseThrow(() -> new ResourceNotFoundException("ApplicationSetting with [KEY= " + key + "] not found"));
    }

    @Override
    public ApplicationSetting saveApplicationSetting(ApplicationSetting applicationSetting) {
        return applicationSettingRepository.save(applicationSetting);
    }

    @Override
    public ApplicationSetting updateApplicationSettingValue(String key, String value) {
        ApplicationSetting setting = getApplicationSettingByKey(key);
        setting.setValue(value);
        return applicationSettingRepository.save(setting);
    }

    @Override
    public String getApplicationSettingValueByKey(String key) {
        return getApplicationSettingByKey(key).getValue();
    }
}
