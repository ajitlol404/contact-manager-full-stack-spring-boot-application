package com.cm.service;

import com.cm.entity.ApplicationSetting;
import com.cm.entity.ApplicationSetting.Category;

import java.util.List;

public interface ApplicationSettingService {

    List<ApplicationSetting> getAllApplicationSettings();

    void saveAllApplicationSetting(Iterable<ApplicationSetting> applicationSettings);

    List<ApplicationSetting> getApplicationSettingsByCategory(Category category);

    ApplicationSetting getApplicationSettingByKey(String key);

    ApplicationSetting saveApplicationSetting(ApplicationSetting applicationSetting);

    ApplicationSetting updateApplicationSettingValue(String key, String value);

    String getApplicationSettingValueByKey(String key);

}
