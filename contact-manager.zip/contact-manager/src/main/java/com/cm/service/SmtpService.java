package com.cm.service;

import com.cm.dto.SmtpDTO.SmtpInputDTO;
import com.cm.dto.SmtpDTO.SmtpResponseDTO;
import com.cm.dto.SmtpDTO.SmtpToggleStatusDTO;

public interface SmtpService {

    SmtpResponseDTO getSmtp();

    SmtpResponseDTO updateSmtp(SmtpInputDTO smtpInputDTO);

    SmtpToggleStatusDTO toggleSmtpStatus(SmtpToggleStatusDTO smtpToggleStatusDTO);

}
