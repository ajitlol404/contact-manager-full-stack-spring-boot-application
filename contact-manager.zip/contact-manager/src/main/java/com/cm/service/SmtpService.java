package com.cm.service;

import com.cm.dto.SmtpDTO.SmtpResponseDTO;

public interface SmtpService {

    SmtpResponseDTO getSmtp();

}
