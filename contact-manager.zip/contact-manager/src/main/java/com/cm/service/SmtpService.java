package com.cm.service;

public interface SmtpService {

}
