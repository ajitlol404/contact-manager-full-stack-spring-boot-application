package com.cm.service;

public interface UserService {

    boolean areThereAdminUsers();

}
