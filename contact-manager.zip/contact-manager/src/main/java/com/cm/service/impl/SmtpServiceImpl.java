package com.cm.service.impl;

import com.cm.dao.ApplicationSettingRepository;
import com.cm.service.SmtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class SmtpServiceImpl implements SmtpService {

    private final ApplicationSettingRepository adminDataRepository;



}
