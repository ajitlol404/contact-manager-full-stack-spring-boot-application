package com.cm.service.impl;

import com.cm.dao.ApplicationSettingRepository;
import com.cm.dto.SmtpDTO.SmtpResponseDTO;
import com.cm.entity.ApplicationSetting;
import com.cm.mapper.SmtpMapper;
import com.cm.service.SmtpService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SmtpServiceImpl implements SmtpService {

    private final ApplicationSettingRepository applicationSettingRepository;

    @Override
    public SmtpResponseDTO getSmtp() {
        List<ApplicationSetting> smtpSettingsList = applicationSettingRepository.findByCategory(ApplicationSetting.Category.SMTP);
        return SmtpMapper.toSmtpResponseDTO(smtpSettingsList);
    }
}
