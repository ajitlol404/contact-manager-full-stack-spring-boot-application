package com.cm.mapper;

import com.cm.dto.ContactDTO.ContactDetailDTO;
import com.cm.entity.ContactDetail;

public class ContactMapper {
    public static ContactDetailDTO toDTO(ContactDetail contactDetail) {
        return new ContactDetailDTO(
                contactDetail.getId(),
                contactDetail.getName(),
                contactDetail.getEmail(),
                contactDetail.getDob(),
                contactDetail.getAddress(),
                contactDetail.getImage(),
                contactDetail.getPhoneNumbers()
        );
    }

    public static ContactDetail toEntity(ContactDetailDTO contactDetailDTO) {
        return ContactDetail.builder()
                .id(contactDetailDTO.id())
                .name(contactDetailDTO.name())
                .email(contactDetailDTO.email())
                .dob(contactDetailDTO.dob())
                .address(contactDetailDTO.address())
                .image(contactDetailDTO.image())
                .phoneNumbers(contactDetailDTO.phoneNumbers())
                .build();
    }
}
