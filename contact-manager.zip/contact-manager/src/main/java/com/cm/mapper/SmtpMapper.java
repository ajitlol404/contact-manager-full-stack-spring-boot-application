package com.cm.mapper;

import com.cm.dto.SmtpDTO.SmtpResponseDTO;
import com.cm.entity.ApplicationSetting;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.cm.helper.AppConstant.*;

public class SmtpMapper {

    public static SmtpResponseDTO toSmtpResponseDTO(List<ApplicationSetting> smtpSettingsList) {

        Map<String, String> settingsMap = smtpSettingsList.stream()
                .collect(Collectors.toMap(ApplicationSetting::getKey, ApplicationSetting::getValue));

        String host = settingsMap.getOrDefault(SMTP_HOST, null);
        Integer port = parseInteger(settingsMap.getOrDefault(SMTP_PORT, null));
        Boolean isSsl = parseBoolean(settingsMap.getOrDefault(SMTP_IS_SSL, null));
        String username = settingsMap.getOrDefault(SMTP_USERNAME, null);
        Boolean status = parseBoolean(settingsMap.getOrDefault(SMTP_STATUS, null));

        return new SmtpResponseDTO(host, port, isSsl, username, status);
    }

    private static Integer parseInteger(String value) {
        try {
            return value != null ? Integer.parseInt(value) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Boolean parseBoolean(String value) {
        return value != null ? Boolean.parseBoolean(value) : null;
    }
}
