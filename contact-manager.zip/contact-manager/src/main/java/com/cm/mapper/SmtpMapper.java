package com.cm.mapper;

import com.cm.dto.SmtpDTO.SmtpResponseDTO;

public class SmtpMapper {

    public static SmtpResponseDTO toSmtpResponseDTO(String host, String port, String username, String isSsl, String status) {

        Integer portInt = parseInteger(port);
        Boolean isSslBool = parseBoolean(isSsl);
        Boolean statusBool = parseBoolean(status);

        return new SmtpResponseDTO(host, portInt, isSslBool, username, statusBool);
    }

    private static Integer parseInteger(String value) {
        try {
            return value != null ? Integer.parseInt(value) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Boolean parseBoolean(String value) {
        return value != null ? Boolean.parseBoolean(value) : null;
    }
}
