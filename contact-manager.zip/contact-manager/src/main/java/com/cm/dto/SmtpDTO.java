package com.cm.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;

public class SmtpDTO {

    public record SmtpInputDTO(
            @NotBlank String host,
            @Min(1) @Max(65535) int port,
            @JsonProperty("is_ssl") boolean isSsl,
            @NotBlank String username,
            @NotBlank String password,
            @JsonProperty("test_email") @NotBlank @Email String testEmail
    ) {

    }

    public record SmtpResponseDTO(
            String host,
            Integer port,
            @JsonProperty("is_ssl") Boolean isSsl,
            String username,
            Boolean status
    ) {

    }

    public record SmtpToggleStatusDTO(
            boolean status
    ) {

    }

}
