package com.cm.dto;

public class SmtpDTO {

    public record SmtpInputDTO(
            String host,
            int port,
            boolean isSsl,
            String username,
            String password,
            String testEmail
    ) {

    }

    public record SmtpResponseDTO(
            String host,
            Integer port,
            Boolean isSsl,
            String username,
            Boolean status
    ) {

    }

}
