package com.cm.dto;

import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.Set;
import java.util.UUID;

public class ContactDTO {

    public record ContactDetailDTO(
            UUID id,
            String name,
            String email,
            LocalDate dob,
            String address,
            String image,
            Set<String> phoneNumbers) {

    }

    public record ContactInputDTO(
            String name,
            String email,
            LocalDate dob,
            String address,
            MultipartFile file,
            Set<String> phoneNumbers) {

    }

}
